const fs = require('fs');

const envFile = 'postman/local-environment.postman_environment.json';
const colFile = 'postman/Shipment-Tracking.postman_collection.json';

const envData = JSON.parse(fs.readFileSync(envFile, 'utf8'));
const colData = JSON.parse(fs.readFileSync(colFile, 'utf8'));

// Build variables map
const vars = {};
for (const v of envData.values) {
  if (v.enabled) {
    vars[v.key] = v.value;
  }
}

function replaceVars(str) {
  if (!str || typeof str !== 'string') return str;
  return str.replace(/\{\{([^\}]+)\}\}/g, (match, key) => {
    return vars[key] !== undefined ? vars[key] : match;
  });
}

function extractRequests(items, folder = '') {
  const list = [];
  for (const it of items) {
    const currentFolder = folder ? `${folder} / ${it.name}` : it.name;
    if (it.item) {
      list.push(...extractRequests(it.item, currentFolder));
    } else if (it.request) {
      list.push({ folder, item: it });
    }
  }
  return list;
}

const allRequests = extractRequests(colData.item);

async function runAll() {
  console.log(`Starting execution of ${allRequests.length} Postman endpoints against ${vars.baseUrl}...\n`);
  
  const results = [];
  let index = 1;

  for (const { folder, item } of allRequests) {
    const req = item.request;
    const method = req.method;
    let rawUrl = typeof req.url === 'object' ? req.url.raw : req.url;
    rawUrl = replaceVars(rawUrl);

    // Prepare headers
    const headers = {};
    if (req.header) {
      for (const h of req.header) {
        if (!h.disabled) {
          headers[h.key] = replaceVars(h.value);
        }
      }
    }

    // Prepare body
    let body = undefined;
    if (req.body && req.body.mode === 'raw' && req.body.raw) {
      body = replaceVars(req.body.raw);
    }

    const startTime = Date.now();
    let resStatus = 0;
    let resStatusText = '';
    let resBodyText = '';
    let resJson = null;
    let error = null;

    try {
      const res = await fetch(rawUrl, {
        method,
        headers,
        body: ['GET', 'HEAD'].includes(method.toUpperCase()) ? undefined : body
      });
      resStatus = res.status;
      resStatusText = res.statusText;
      resBodyText = await res.text();
      try {
        resJson = JSON.parse(resBodyText);
      } catch (e) {
        resJson = null;
      }
    } catch (err) {
      error = err.message;
    }
    const duration = Date.now() - startTime;

    console.log(`================================================================================`);
    console.log(`[#${index++}] Folder: ${folder}`);
    console.log(`Request: ${item.name}`);
    console.log(`HTTP ${method} ${rawUrl}`);
    console.log(`Headers: ${JSON.stringify(headers, null, 2)}`);
    if (body) {
      console.log(`Request Body:\n${body}`);
    }
    console.log(`--------------------------------------------------------------------------------`);
    if (error) {
      console.log(`ERROR: ${error}`);
    } else {
      console.log(`Response Status: ${resStatus} ${resStatusText} (${duration} ms)`);
      console.log(`Response Body:\n${resJson ? JSON.stringify(resJson, null, 2) : resBodyText}`);
    }
    console.log(`================================================================================\n`);

    results.push({
      index: index - 1,
      name: item.name,
      folder,
      method,
      url: rawUrl,
      status: resStatus,
      duration,
      body: resJson || resBodyText,
      error
    });
  }

  // Summary Table
  console.log(`\n============================ SUMMARY REPORT ============================`);
  results.forEach(r => {
    console.log(`${String(r.index).padStart(2, ' ')}. [${r.status}] ${r.method.padEnd(6, ' ')} ${r.name}`);
  });
  console.log(`========================================================================\n`);

  fs.writeFileSync('postman/test-run-results.json', JSON.stringify(results, null, 2), 'utf8');
}

runAll().catch(console.error);
